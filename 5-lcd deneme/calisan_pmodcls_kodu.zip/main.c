#include <stm32f10x.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_usart.h>
#include <stm32f10x_spi.h>
#include <stdio.h>
#include <string.h>


#define ESC 								0x1B
#define BRACKET							0x5B //[
#define CURSOR_POS_CMD			0x48 //H
#define CURSOR_SAVE_CMD			0x73 //s
#define CURSOR_RSTR_CMD			0x75 //u
#define DISP_CLR_CMD				0x6A //j
#define ERASE_INLINE_CMD		0x4B //K
#define ERASE_FIELD_CMD			0x4E //N
#define LSCROLL_CMD					0x40 //@
#define RSCROLL_CMD					0x41 //A
#define RST_CMD							0x2A //*
#define DISP_EN_CMD					0x65 //e
#define DISP_MODE_CMD				0x68 //h
#define CURSOR_MODE_CMD			0x63 //c
#define TWI_SAVE_ADDR_CMD		0x61 //a
#define BR_SAVE_CMD							0x62 //b
#define PRG_CHAR_CMD						0x70 //p
#define SAVE_RAM_TO_EEPROM_CMD	0x74 //t
#define LD_EEPROM_TO_RAM_CMD		0x6C //l
#define DEF_CHAR_CMD						0x64 //d
#define COMM_MODE_SAVE_CMD			0x6D //m
#define EEPROM_WR_EN_CMD				0x77 //w
#define CURSOR_MODE_SAVE_CMD		0x6E //n
#define DISP_MODE_SAVE_CMD			0x6F //o


#define LCDS_ERR_SUCCESS			0	// The action completed successfully
#define LCDS_ERR_ARG_ROW_RANGE		1	// The argument is not within 0, 2 range for rows
#define LCDS_ERR_ARG_COL_RANGE		2	// The argument is not within 0, 39 range
#define LCDS_ERR_ARG_ERASE_OPTIONS	3	// The argument is not within 0, 2 range for erase types
#define LCDS_ERR_ARG_BR_RANGE		4	// The argument is not within 0, 6 range
#define LCDS_ERR_ARG_TABLE_RANGE	5	// The argument is not within 0, 3 range for table selection
#define LCDS_ERR_ARG_COMM_RANGE		6	// The argument is not within 0, 7 range
#define LCDS_ERR_ARG_CRS_RANGE		7	// The argument is not within 0, 2 range for cursor modes
#define LCDS_ERR_ARG_DSP_RANGE		8	// The argument is not within 0, 3 range for display settings types
#define LCDS_ERR_ARG_POS_RANGE		9	// The argument is not within 0, 7 range for characters position in the memory


#define CS_PIN			GPIO_Pin_3

#define USART1_Rx GPIO_Pin_10
#define USART1_Tx GPIO_Pin_9

uint8_t         defChar[] = {0, 0x4, 0x2, 0x1F, 0x02, 0x4, 0, 0};
uint8_t         defChar1[] = {14, 31, 21, 31, 23, 16, 31, 14};
uint8_t         defChar2[] = {0x00, 0x1F, 0x11, 0x00, 0x00, 0x11, 0x1F, 0x00};
uint8_t         defChar3[] = {0x00, 0x0A, 0x15, 0x11, 0x0A, 0x04, 0x00, 0x00};



void Delay_MS(uint32_t nCount)
{ 
	uint32_t i;
	nCount = nCount*(SystemCoreClock/5000);
  for(i=0;i<nCount;i++);
}

void lcdInitSPI()
{

	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef  SPI_InitStructure;


	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);


	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;

	/* SPI SCK pin configuration */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 |GPIO_Pin_13 | GPIO_Pin_15;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	/* SPI configuration -------------------------------------------------------*/
	SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Hard;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_64;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;

	SPI_Init(SPI2, &SPI_InitStructure);


	GPIO_InitStructure.GPIO_Pin = CS_PIN; 				//CS Pin
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_SetBits(GPIOB,CS_PIN);
	
  /* Enable SPI2  */
  	SPI_SSOutputCmd(SPI2, ENABLE);
	SPI_Cmd(SPI2, ENABLE);
	Delay_MS(100);
}

void SPI_SEND_BYTE(uint8_t byte)
{

	GPIO_ResetBits(GPIOB,CS_PIN);
	while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
	SPI_I2S_SendData(SPI2, byte);
	GPIO_SetBits(GPIOB,CS_PIN);
}

void Send_bytes(uint8_t *data, uint8_t dataSize){
	int i;

	for(i = 0; i < dataSize ; i++)
	{
		SPI_SEND_BYTE(data[i]);
	}

}

void DisplaySet(uint8_t setDisplay, uint8_t setBckl){
	
	uint8_t dispBcklOff []  = {ESC, BRACKET, '0', DISP_EN_CMD};
	uint8_t dispOnBckl  []  = {ESC, BRACKET, '1', DISP_EN_CMD};
	uint8_t dispBcklOn  []  = {ESC, BRACKET, '2', DISP_EN_CMD};
	uint8_t dispOnBcklOn[]  = {ESC, BRACKET, '3', DISP_EN_CMD};
	
	if ((!setDisplay)&&(!setBckl))	{
		//send the command for both display and backlight off
		Send_bytes(dispBcklOff, 4);
	}
	else if ((setDisplay)&&(!setBckl))	{
		//send the command for display on and backlight off
		Send_bytes(dispOnBckl, 4);
	}
	else if ((!setDisplay)&&(setBckl))	{
			//send the command for backlight on and display off
			Send_bytes(dispBcklOn, 4);
	}
	else {
				//send the command for both display and backlight on
				Send_bytes(dispOnBcklOn, 4);
	}
}


void DisplayClear() {
	uint8_t dispClr[] =  {ESC, BRACKET, '0',DISP_CLR_CMD};
	//clear the display and returns the cursor home
	Send_bytes(dispClr, 4);
}

void DisplayMode(uint8_t charNumber){
	uint8_t dispMode16[] = {ESC, BRACKET, '0', DISP_MODE_CMD};
	uint8_t dispMode40[] = {ESC, BRACKET, '1', DISP_MODE_CMD};
	if (charNumber){
		//wrap line at 16 characters
		Send_bytes(dispMode16, 4);
	}
	else{
		//wrap line at 40 characters
		Send_bytes(dispMode40, 4);
	}
}

uint8_t WriteStringAtPos(uint8_t idxRow, uint8_t idxCol, const uint8_t strLn[], uint8_t lengt_Data) {

	uint8_t bResult = LCDS_ERR_SUCCESS;
	if (idxRow < 0 || idxRow > 2){
		bResult |= LCDS_ERR_ARG_ROW_RANGE;
	}
	if (idxCol < 0 || idxCol > 39){
		bResult |= LCDS_ERR_ARG_COL_RANGE;
	}
	if (bResult == LCDS_ERR_SUCCESS){
		//separate the position digits in order to send them, useful when the position is greater than 10
		uint8_t firstDigit 		= idxCol % 10;
		uint8_t secondDigit 	= idxCol / 10;
		uint8_t length 			= lengt_Data;
		uint8_t lengthToPrint   = length + idxCol;
		if (lengthToPrint > 40) {
			//truncate the lenght of the string 
			//if it's greater than the positions number of a line
			length = 40 - idxCol;
		}
		
		SPI_SEND_BYTE(ESC);
		SPI_SEND_BYTE(BRACKET);
		SPI_SEND_BYTE(idxRow + '0');
		SPI_SEND_BYTE(';');
		SPI_SEND_BYTE(secondDigit + '0');
		SPI_SEND_BYTE(firstDigit + '0');
		SPI_SEND_BYTE(CURSOR_POS_CMD);
		Send_bytes((uint8_t *)strLn, length);
	}
	return bResult;
}

void buildUserDefChar(uint8_t* strUserDef, char* cmdStr) {
	uint8_t len = 8,i;
	char elStr[4];
	//print the bytes from the input array as hex values
	for(i = 0; i < len; i++){
		sprintf(elStr, "%2.2X", strUserDef[i]);
		//concatenate the result with the 0x chars to be able to send it to the LCD
		strcat(cmdStr, "0x");
		//since the Arduino compiler has a bug in the sprintf function, so it doesn't interpret the 
		//precision and width specifiers as it should, by adding a 0 in front of a number greater than 16,
		//we need to eliminate that 0 from the string
		if (strUserDef[i] > 15) {
			elStr[3] = 0;
			strcat(cmdStr, elStr + 1);
		}
		else {
			elStr[2] = 0;
			strcat(cmdStr, elStr);
		}
		strcat(cmdStr, ";");
	}
}


uint8_t DefineUserChar(uint8_t* strUserDef, uint8_t charPos) {
	char rgcCmd[150];
	uint8_t bLength;
	uint8_t bResult;
	if (charPos >= 0 && charPos <= 7){
		rgcCmd[0] = ESC;
		rgcCmd[1] = BRACKET;
		rgcCmd[2] = 0;
		//build the values to be sent for defining the custom character
		buildUserDefChar(strUserDef, rgcCmd + 2);
		bLength = strlen(rgcCmd);
		rgcCmd[bLength++] = (char)charPos + '0';
		rgcCmd[bLength++] = DEF_CHAR_CMD;
		//save the defined character in the RAM
		rgcCmd[bLength++] = ESC;
		rgcCmd[bLength++] = BRACKET;
		rgcCmd[bLength++] = '3';
		rgcCmd[bLength++] = PRG_CHAR_CMD;
		Send_bytes((unsigned char*)(rgcCmd), bLength);
		bResult = LCDS_ERR_SUCCESS;
	}
	else {
		bResult = LCDS_ERR_ARG_POS_RANGE;
	}
	return bResult;
}


int main(){
	uint8_t name[] = "Furkan";
	uint8_t suname[] = "tlmaz";

	
	lcdInitSPI();
	DisplaySet(1,1);
	DisplayMode(1);
	DefineUserChar(defChar, 0);
	Delay_MS(50);
	DefineUserChar(defChar1, 1);
	Delay_MS(50);
	DefineUserChar(defChar2, 2);
	Delay_MS(50);
	DefineUserChar(defChar3, 3);
	Delay_MS(50);

	DisplayClear();
	Delay_MS(100);
	WriteStringAtPos(0, 1,suname,strlen("tlmaz"));
	WriteStringAtPos(1, 1,name,strlen("Furkan")+1);

	while(1){

	}
}
